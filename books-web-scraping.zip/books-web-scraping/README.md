# 📚 Books Web Scraping

A complete scraping pipeline for [Books to Scrape](https://books.toscrape.com): crawl every catalogue page, visit every book's detail page, validate the result and explore it.

**Tools:** Python · Requests · BeautifulSoup · lxml · Pandas · Matplotlib · Seaborn

## What it does
1. **Crawl** (`scraper.py`) – follows the "next" button through all 50 catalogue pages (20 books each, 1,000 books), then opens each book page. Uses a session with automatic retries / back-off and a polite delay between requests.
2. **Extract** – title, price (GBP, as a number), star rating (1-5), availability, in-stock flag, stock count, category, UPC, description, product URL, image URL and the page it was found on.
3. **Validate** (`validate.py`) – checks missing values, duplicate URLs / UPCs, rating range and price sanity, then writes `data/validation_report.txt`.
4. **Explore** (`analyze.py`) – price distribution, rating counts, top categories and a per-category summary table (`data/category_summary.csv`, charts in `images/`).

## How to run
```bash
pip install -r requirements.txt
python scraper.py        # ~5 min; writes data/books.csv   (add --no-details for a fast list-only crawl)
python validate.py       # completeness report
python analyze.py        # charts + category summary
```

Useful options: `--delay 0.5` (be gentler), `--max-pages 3` (quick test), `--out file.csv`.

## Test offline
`tests/mock_site.py` serves a local copy of the site's HTML structure (50 pages x 20 books) so the scraper can be tested without internet:
```bash
python tests/mock_site.py &
python scraper.py --base-url http://127.0.0.1:8000/ --delay 0 --out data/test.csv
```

## Output columns
| column | description |
|---|---|
| title | full book title (taken from the link's `title` attribute, not the truncated text) |
| price_gbp | price as float |
| rating | 1-5 |
| availability / in_stock / stock_count | stock text, boolean, units available |
| category | from the breadcrumb on the detail page |
| upc | unique product code |
| description | product description (a few books on the site have none) |
| product_url / image_url | absolute URLs |
| page | catalogue page number |

## Notes
* The site is a sandbox built for scraping practice; still, keep the delay on and don't hammer it.
* Prices are decoded as UTF-8 explicitly, otherwise the `£` sign is mangled.
* Completeness is measured on all columns except `description`, because the source itself leaves it empty for some books.

## Project structure
```
books-web-scraping/
├── scraper.py
├── validate.py
├── analyze.py
├── requirements.txt
├── tests/mock_site.py
├── data/      # books.csv, validation_report.txt, category_summary.csv
└── images/    # charts from analyze.py
```
