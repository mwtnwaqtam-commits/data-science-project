"""Tiny local site that mimics the HTML structure of books.toscrape.com
(50 pages x 20 books). Lets you test the scraper offline:
    python tests/mock_site.py          # serves http://127.0.0.1:8000/
    python scraper.py --base-url http://127.0.0.1:8000/ --delay 0
"""
import random
from http.server import BaseHTTPRequestHandler, HTTPServer

random.seed(7)
CATS = ["Travel", "Mystery", "Historical Fiction", "Sequential Art", "Classics", "Philosophy", "Romance", "Womens Fiction", "Fiction", "Childrens"]
WORDS = ["Silent", "Garden", "Night", "River", "Secret", "Last", "Winter", "Light", "Stone", "Wild"]
STARS = ["One", "Two", "Three", "Four", "Five"]
BOOKS = []
for i in range(1000):
    BOOKS.append(dict(id=i + 1, title=f"{random.choice(WORDS)} {random.choice(WORDS)} {i + 1}",
                      price=round(random.uniform(10, 60), 2), star=random.choice(STARS),
                      cat=random.choice(CATS), stock=random.randint(1, 22),
                      desc=None if i % 97 == 0 else f"Description of book {i + 1}. A story worth reading."))


def list_page(n):
    prefix = "catalogue/" if n == 1 else ""
    items = "".join(f'''<li><article class="product_pod"><div class="image_container"><a href="{prefix}book_{b["id"]}/index.html"><img src="media/{b["id"]}.jpg"></a></div>
<p class="star-rating {b["star"]}"></p><h3><a href="{prefix}book_{b["id"]}/index.html" title="{b["title"]}">{b["title"][:20]}...</a></h3>
<div class="product_price"><p class="price_color">\u00a3{b["price"]:.2f}</p><p class="instock availability"><i class="icon-ok"></i>
    In stock
</p></div></article></li>''' for b in BOOKS[(n - 1) * 20:n * 20])
    nxt = f'<li class="next"><a href="{"catalogue/" if n == 1 else ""}page-{n + 1}.html">next</a></li>' if n < 50 else ""
    return f"<html><body><ol class='row'>{items}</ol><ul class='pager'>{nxt}</ul></body></html>"


def detail_page(i):
    b = BOOKS[i - 1]
    desc = f'<div id="product_description" class="sub-header"><h2>Product Description</h2></div><p>{b["desc"]}</p>' if b["desc"] else ""
    return f'''<html><body><ul class="breadcrumb"><li><a href="/">Home</a></li><li><a href="/">Books</a></li><li><a href="/">{b["cat"]}</a></li><li class="active">{b["title"]}</li></ul>
{desc}<table class="table table-striped"><tr><th>UPC</th><td>upc{i:08d}</td></tr><tr><th>Availability</th><td>In stock ({b["stock"]} available)</td></tr></table></body></html>'''


class H(BaseHTTPRequestHandler):
    def do_GET(self):
        p = self.path.strip("/")
        try:
            if p in ("", "index.html"): body = list_page(1)
            elif p.startswith("catalogue/page-"): body = list_page(int(p.split("-")[1].split(".")[0]))
            elif p.startswith("catalogue/book_"): body = detail_page(int(p.split("_")[1].split("/")[0]))
            else: raise KeyError
        except Exception:
            self.send_response(404); self.end_headers(); return
        self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.end_headers()
        self.wfile.write(body.encode("utf-8"))

    def log_message(self, *a): pass


if __name__ == "__main__":
    print("Mock site on http://127.0.0.1:8000/")
    HTTPServer(("127.0.0.1", 8000), H).serve_forever()
