"""Validate the scraped CSV: completeness, duplicates, ranges. Prints a report
and writes data/validation_report.txt. Exit code 1 if any check fails."""
import sys
import pandas as pd

path = sys.argv[1] if len(sys.argv) > 1 else "data/books.csv"
df = pd.read_csv(path)
# 'description' is legitimately empty for a few books on the source site, so it is reported separately
core = [c for c in df.columns if c != "description"]

lines = [f"File: {path}", f"Rows: {len(df)}  Columns: {df.shape[1]}",
         f"Pages crawled: {df['page'].nunique()}", ""]
missing = df.isna().sum()
lines.append("Missing values per column:")
lines += [f"  {c:<14}{n}" for c, n in missing.items()]
completeness = 1 - df[core].isna().sum().sum() / df[core].size
lines += ["", f"Completeness (excluding description): {completeness:.2%}"]

checks = {
    "no missing values in core columns": df[core].isna().sum().sum() == 0,
    "no duplicate product_url": not df["product_url"].duplicated().any(),
    "no duplicate UPC": not df["upc"].duplicated().any(),
    "rating within 1-5": df["rating"].between(1, 5).all(),
    "price > 0": (df["price_gbp"] > 0).all(),
}
lines.append("")
lines += [f"[{'PASS' if ok else 'FAIL'}] {name}" for name, ok in checks.items()]
report = "\n".join(lines)
print(report)
open("data/validation_report.txt", "w", encoding="utf-8").write(report + "\n")
sys.exit(0 if all(checks.values()) else 1)
