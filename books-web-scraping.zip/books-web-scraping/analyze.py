"""Quick exploratory analysis of the scraped books. Saves charts to images/."""
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

path = sys.argv[1] if len(sys.argv) > 1 else "data/books.csv"
df = pd.read_csv(path)
sns.set_theme(style="whitegrid")

fig, ax = plt.subplots(figsize=(7, 4))
sns.histplot(df["price_gbp"], bins=25, ax=ax, color="#4f46e5")
ax.set(title="Price distribution (GBP)", xlabel="Price (£)")
fig.tight_layout(); fig.savefig("images/price_distribution.png", dpi=150); plt.close(fig)

fig, ax = plt.subplots(figsize=(6, 4))
sns.countplot(x="rating", data=df, ax=ax, color="#4f46e5")
ax.set(title="Books by star rating")
fig.tight_layout(); fig.savefig("images/rating_counts.png", dpi=150); plt.close(fig)

top = df["category"].value_counts().head(10)
fig, ax = plt.subplots(figsize=(7, 5))
sns.barplot(x=top.values, y=top.index, ax=ax, color="#4f46e5")
ax.set(title="Top 10 categories by number of books", xlabel="Books", ylabel="")
fig.tight_layout(); fig.savefig("images/top_categories.png", dpi=150); plt.close(fig)

summary = df.groupby("category").agg(books=("title", "count"), avg_price=("price_gbp", "mean"),
                                     avg_rating=("rating", "mean")).round(2).sort_values("books", ascending=False)
summary.to_csv("data/category_summary.csv")
print(f"{len(df)} books | avg price £{df.price_gbp.mean():.2f} | avg rating {df.rating.mean():.2f}")
print(f"{df.category.nunique()} categories | in stock: {df.in_stock.mean():.1%}")
print(summary.head(10))
