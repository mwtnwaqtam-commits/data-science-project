"""Books to Scrape - web scraper.

Crawls every catalogue page of https://books.toscrape.com, then (optionally)
visits each book's detail page, and saves a structured CSV.

Usage:
    python scraper.py                      # full crawl with detail pages
    python scraper.py --no-details         # list pages only (much faster)
    python scraper.py --base-url http://127.0.0.1:8000/   # test against a mock site
"""
import argparse
import re
import time
from urllib.parse import urljoin

import pandas as pd
import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "https://books.toscrape.com/"
RATING_MAP = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
COLUMNS = ["title", "price_gbp", "rating", "availability", "in_stock", "stock_count",
           "category", "upc", "description", "product_url", "image_url", "page"]


def make_session():
    s = requests.Session()
    retry = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
    s.mount("http://", HTTPAdapter(max_retries=retry))
    s.mount("https://", HTTPAdapter(max_retries=retry))
    s.headers.update({"User-Agent": "Mozilla/5.0 (portfolio scraping project)"})
    return s


def get_soup(session, url):
    r = session.get(url, timeout=20)
    r.raise_for_status()
    r.encoding = "utf-8"  # otherwise the pound sign is decoded wrongly
    return BeautifulSoup(r.text, "lxml")


def parse_list_page(soup, page_url, page_no):
    rows = []
    for art in soup.select("article.product_pod"):
        a = art.select_one("h3 a")
        rating_cls = art.select_one("p.star-rating")["class"]
        rating_word = next((c for c in rating_cls if c in RATING_MAP), None)
        price_txt = art.select_one("p.price_color").get_text(strip=True)
        avail = art.select_one("p.instock.availability").get_text(strip=True)
        img = art.select_one("img")["src"]
        rows.append({
            "title": a["title"].strip(),
            "price_gbp": float(re.sub(r"[^\d.]", "", price_txt)),
            "rating": RATING_MAP.get(rating_word),
            "availability": avail,
            "in_stock": "in stock" in avail.lower(),
            "product_url": urljoin(page_url, a["href"]),
            "image_url": urljoin(page_url, img),
            "page": page_no,
        })
    return rows


def parse_detail_page(soup):
    crumbs = soup.select("ul.breadcrumb li a")
    category = crumbs[2].get_text(strip=True) if len(crumbs) >= 3 else None
    table = {tr.th.get_text(strip=True): tr.td.get_text(strip=True)
             for tr in soup.select("table.table-striped tr")}
    desc_tag = soup.select_one("#product_description")
    desc = None
    if desc_tag is not None:
        p = desc_tag.find_next_sibling("p")
        desc = p.get_text(strip=True) if p else None
    m = re.search(r"(\d+)\s+available", table.get("Availability", ""))
    return {
        "category": category,
        "upc": table.get("UPC"),
        "stock_count": int(m.group(1)) if m else None,
        "description": desc,
    }


def crawl(base_url, details=True, delay=0.2, max_pages=None):
    session = make_session()
    rows, page_no = [], 1
    next_url = urljoin(base_url, "index.html")
    while next_url and (max_pages is None or page_no <= max_pages):
        soup = get_soup(session, next_url)
        page_rows = parse_list_page(soup, next_url, page_no)
        rows.extend(page_rows)
        print(f"[list] page {page_no}: {len(page_rows)} books (total {len(rows)})")
        nxt = soup.select_one("li.next a")
        next_url = urljoin(next_url, nxt["href"]) if nxt else None
        page_no += 1
        time.sleep(delay)

    if details:
        for i, row in enumerate(rows, 1):
            row.update(parse_detail_page(get_soup(session, row["product_url"])))
            if i % 50 == 0 or i == len(rows):
                print(f"[detail] {i}/{len(rows)}")
            time.sleep(delay)

    df = pd.DataFrame(rows)
    for c in COLUMNS:
        if c not in df.columns:
            df[c] = None
    return df[COLUMNS]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default=BASE_URL)
    ap.add_argument("--no-details", action="store_true")
    ap.add_argument("--delay", type=float, default=0.2)
    ap.add_argument("--max-pages", type=int, default=None)
    ap.add_argument("--out", default="data/books.csv")
    a = ap.parse_args()
    df = crawl(a.base_url, details=not a.no_details, delay=a.delay, max_pages=a.max_pages)
    df.to_csv(a.out, index=False, encoding="utf-8")
    print(f"\nSaved {len(df)} rows x {df.shape[1]} columns -> {a.out}")


if __name__ == "__main__":
    main()
