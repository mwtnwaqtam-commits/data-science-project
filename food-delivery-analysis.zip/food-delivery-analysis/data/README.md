# Data folder

Place the raw file here as **`train.csv`**
(Kaggle - *Food Delivery Dataset*, 45,593 rows x 20 columns).

Running the notebook will also write `food_delivery_cleaned.csv` into this folder.
